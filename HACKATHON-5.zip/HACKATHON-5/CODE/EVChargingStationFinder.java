import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

class ChargingStation {
    private String name;
    private String location;
    private Map<String, Integer> availableSlots; // Time-based slots
    private String chargingType; // e.g., Fast Charging, Normal Charging
    private List<String> reviews;

    public ChargingStation(String name, String location, int totalSlots, String chargingType) {
        this.name = name;
        this.location = location;
        this.chargingType = chargingType;
        this.reviews = new ArrayList<>();
        this.availableSlots = new HashMap<>();
        // Initialize available slots for each hour (e.g., 9 AM to 9 PM)
        for (int i = 9; i <= 21; i++) {
            this.availableSlots.put(i + ":00", totalSlots);
        }
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getChargingType() {
        return chargingType;
    }

    public boolean bookSlot(String time) {
        if (availableSlots.containsKey(time) && availableSlots.get(time) > 0) {
            availableSlots.put(time, availableSlots.get(time) - 1);
            return true;
        } else {
            return false;
        }
    }

    public void addReview(String review) {
        reviews.add(review);
    }

    public void viewReviews() {
        if (reviews.isEmpty()) {
            System.out.println("No reviews yet.");
        } else {
            System.out.println("Reviews for " + name + ":");
            for (String review : reviews) {
                System.out.println("- " + review);
            }
        }
    }

    public void showAvailableSlots() {
        System.out.println("Available Slots for " + name + " (" + location + "):");
        System.out.println("+-------+-----------------+");
        System.out.println("| Time  | Available Slots |");
        System.out.println("+-------+-----------------+");
        for (Map.Entry<String, Integer> entry : availableSlots.entrySet()) {
            System.out.printf("| %-5s | %-15d |\n", entry.getKey(), entry.getValue());
        }
        System.out.println("+-------+-----------------+");
    }

    @Override
    public String toString() {
        return "Charging Station: " + name + " | Location: " + location + " | Charging Type: " + chargingType;
    }
}

class EVChargingSystem {
    private List<ChargingStation> stations;
    private List<String> bookingHistory;
    private Random random;

    public EVChargingSystem() {
        stations = new ArrayList<>();
        bookingHistory = new ArrayList<>();
        random = new Random();
        initializeStations();
    }

    private void initializeStations() {
        stations.add(new ChargingStation("EV Station Mumbai", "Mumbai", 5, "Fast Charging"));
        stations.add(new ChargingStation("Charge Point Bangalore", "Bangalore", 4, "Normal Charging"));
        stations.add(new ChargingStation("Green Charge Delhi", "Delhi", 2, "Fast Charging"));
        stations.add(new ChargingStation("Zap Charge Hyderabad", "Hyderabad", 3, "Normal Charging"));
        stations.add(new ChargingStation("QuickCharge Chennai", "Chennai", 6, "Fast Charging"));
        stations.add(new ChargingStation("Eco Charge Pune", "Pune", 0, "Normal Charging"));  // No slots available
        stations.add(new ChargingStation("PowerUp Kolkata", "Kolkata", 7, "Fast Charging"));
        stations.add(new ChargingStation("ChargeMaster Ahmedabad", "Ahmedabad", 2, "Normal Charging"));
        stations.add(new ChargingStation("Electra Charge Jaipur", "Jaipur", 1, "Fast Charging"));
        stations.add(new ChargingStation("Volt Charging Station", "Lucknow", 5, "Normal Charging"));
    }

    private String generateRegistrationID() {
        return String.format("%04d", random.nextInt(10000));
    }

    public void findStations(String filter, String chargingType) {
        for (ChargingStation station : stations) {
            if ((station.getLocation().equalsIgnoreCase(filter) || station.getName().equalsIgnoreCase(filter)) 
                && station.getChargingType().equalsIgnoreCase(chargingType)) {
                System.out.println(station);
            }
        }
    }

    public void bookChargingSlot(String stationName, String time) {
        for (ChargingStation station : stations) {
            if (station.getName().equalsIgnoreCase(stationName)) {
                if (station.bookSlot(time)) {
                    String registrationID = generateRegistrationID();
                    String booking = String.format("| %-20s | %-15s | %-15s | %-10s | %-10s |", stationName, station.getLocation(), station.getChargingType(), time, registrationID);
                    bookingHistory.add(booking);
                    System.out.println("Slot booked successfully at " + stationName + " for " + time);
                    System.out.println("Your registration ID is: " + registrationID);
                } else {
                    System.out.println("No slots available at " + stationName + " for " + time);
                }
                return;
            }
        }
        System.out.println("Charging station not found.");
    }

    public void addReview(String stationName, String review) {
        for (ChargingStation station : stations) {
            if (station.getName().equalsIgnoreCase(stationName)) {
                station.addReview(review);
                System.out.println("Review added successfully.");
                return;
            }
        }
        System.out.println("Charging station not found.");
    }

    public void viewStationReviews(String stationName) {
        for (ChargingStation station : stations) {
            if (station.getName().equalsIgnoreCase(stationName)) {
                station.viewReviews();
                return;
            }
        }
        System.out.println("Charging station not found.");
    }

    public void viewBookingHistory() {
        if (bookingHistory.isEmpty()) {
            System.out.println("No booking history found.");
        } else {
            System.out.println("Booking History:");
            System.out.println("+----------------------+-----------------+-----------------+------------+------------+");
            System.out.println("| Station Name         | Location        | Charging Type   | Time       | Reg ID     |");
            System.out.println("+----------------------+-----------------+-----------------+------------+------------+");
            for (String history : bookingHistory) {
                System.out.println(history);
            }
            System.out.println("+----------------------+-----------------+-----------------+------------+------------+");
        }
    }

    public void showStationAvailability(String stationName) {
        for (ChargingStation station : stations) {
            if (station.getName().equalsIgnoreCase(stationName)) {
                station.showAvailableSlots();
                return;
            }
        }
        System.out.println("Charging station not found.");
    }
}

public class EVChargingStationFinder {
    public static void main(String[] args) {
        EVChargingSystem system = new EVChargingSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nWelcome to EV Charging Station Finder and Slot Booking System!");
            System.out.println("1. Find Charging Stations");
            System.out.println("2. View Station Availability");
            System.out.println("3. Book a Charging Slot");
            System.out.println("4. Add a Review");
            System.out.println("5. View Station Reviews");
            System.out.println("6. View Booking History");
            System.out.println("7. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter location or station name to filter: ");
                    String filter = scanner.nextLine();
                    System.out.print("Enter charging type (Fast Charging/Normal Charging): ");
                    String chargingType = scanner.nextLine();
                    system.findStations(filter, chargingType);
                    break;

                case 2:
                    System.out.print("Enter the name of the station to view availability: ");
                    String stationNameForAvailability = scanner.nextLine();
                    system.showStationAvailability(stationNameForAvailability);
                    break;

                case 3:
                    System.out.print("Enter the name of the station to book a slot: ");
                    String stationName = scanner.nextLine();
                    System.out.print("Enter the time (e.g., 9:00, 10:00): ");
                    String time = scanner.nextLine();
                    system.bookChargingSlot(stationName, time);
                    break;

                case 4:
                    System.out.print("Enter the name of the station to review: ");
                    stationName = scanner.nextLine();
                    System.out.print("Enter your review: ");
                    String review = scanner.nextLine();
                    system.addReview(stationName, review);
                    break;

                case 5:
                    System.out.print("Enter the name of the station to view reviews: ");
                    stationName = scanner.nextLine();
                    system.viewStationReviews(stationName);
                    break;

                case 6:
                    system.viewBookingHistory();
                    break;

                case 7:
                    System.out.println("Thank you for using the system!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
